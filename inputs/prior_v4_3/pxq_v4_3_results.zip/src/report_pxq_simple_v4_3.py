"""Create the portable report input and an auditable Python-cell notebook."""
import ast
import contextlib
import io
import json
from pathlib import Path
import pandas as pd

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'outputs/pxq_simple_v4_3'
REPORT=ROOT/'reports/pxq_simple_v4_3'
H={'30_day_proxy':'28天代理','60_day_proxy':'63天代理','90_day_proxy':'91天代理'}
M={'Laplace':'SKU加一平滑','EnterpriseShrink_L4':'企业整体收缩','ProfileShrink_L4':'同画像收缩',
   'PXQ_independence':'旧周独立换算','SKU_recent_block':'SKU未平滑',
   'Laplace_mean':'概率×条件均值','MA4_proxy':'MA4','Naive':'Naive'}


def build():
    check=json.loads((OUT/'validation_summary.json').read_text())
    assert check['valid'] and check['checks_passed']==21
    REPORT.mkdir(parents=True,exist_ok=True)
    def read(n):return pd.read_csv(OUT/(n+'.csv'))
    def rows(f):return json.loads(f.to_json(orient='records',force_ascii=False))
    def labels(f):
        r=f.copy();r['周期']=r.horizon_label.map(H)
        if 'method' in r:r['方法']=r.method.map(M).fillna(r.method)
        return r
    p=labels(read('probability_summary'))
    q=labels(read('quantity_summary').query("method in ['Laplace_mean','MA4_proxy','Naive']"))
    pair=labels(read('paired_quantity').query("method == 'Laplace_mean' and baseline == 'MA4_proxy' and loss == 'mase_52'"))
    coverage=labels(read('coverage_summary'))
    rb=labels(read('reliability_bins').query("method=='Laplace'"));rb['概率档']=rb['lower'].map(lambda x:f'{x:.0%}')+'–'+rb['upper'].map(lambda x:f'{x:.0%}')
    qprofile=labels(read('quantity_by_profile').query("method in ['Laplace_mean','MA4_proxy']"))
    qprofile['画像']=qprofile.cluster_profile.map({'relative_active_persistent':'活跃持续','low_frequency_sparse':'低频稀疏','low_information':'低信息'})
    pprofile=labels(read('probability_by_profile').query("method=='Laplace'"));pprofile['画像']=pprofile.cluster_profile.map({'relative_active_persistent':'活跃持续','low_frequency_sparse':'低频稀疏','low_information':'低信息'})
    zero=labels(read('ma4_zero_probability'))
    cond=labels(read('conditional_quantity_summary'));cond['方法']=cond.method.map({'q_mean':'条件均值','q_median':'条件中位数'})
    timestamp=pd.Timestamp.now(tz='UTC').isoformat()
    sources=[]
    for id,name in [('prob','probability_summary'),('quant','quantity_summary'),('paired','paired_quantity'),('cover','coverage_summary'),('bins','reliability_bins'),('profile','probability_by_profile'),('qprofile','quantity_by_profile'),('zero','ma4_zero_probability'),('conditional','conditional_quantity_summary')]:
        sources.append(dict(id=id,label='V4.3 '+name+'.csv',path='outputs/pxq_simple_v4_3/'+name+'.csv',
            query=dict(language='python',engine='Python/pandas',executed_at=timestamp,
                       description='冻结协议V4.3的回顾性计算；训练仅使用起点之前数据，旧模型预测复用。',
                       tables_used=[name+'.csv'],filters=['4/9/13周各6起点','同一SKU–起点比较','不可计算样本单独审计'],
                       metric_definitions={'Brier':'mean((p-z)^2); brier_sku_macro为先SKU内平均、再SKU等权',
                                           'MASE':'周期总量绝对误差/训练期相邻周期总量平均绝对差；零尺度不计算'})))
    sources.extend([dict(id='protocol',label='V4.3冻结协议',path='protocol/amendment_v4.3_simple_probability_mase.md'),
                    dict(id='fpp',label='Hyndman & Athanasopoulos: 预测误差评价',href='https://otexts.com/fpp3/accuracy.html'),
                    dict(id='scoring',label='Gneiting & Raftery (2007): Proper scoring rules',href='https://sites.stat.washington.edu/raftery/Research/PDF/Gneiting2007jasa.pdf')])
    title='V4.3：需求发生概率与MA4公平比较'
    blocks=[];charts=[];tables=[];datasets={}
    def md(id,text,source=None):
        b=dict(id=id,type='markdown',body=text)
        if source:b['sourceId']=source
        blocks.append(b)
    def table(id,title,data,columns,source,sort='周期'):
        datasets[id]=rows(data)
        tables.append(dict(id=id,title=title,dataset=id,sourceId=source,defaultSort=dict(field=sort,direction='asc'),
                           columns=[dict(field=f,label=l,**({'format':fmt} if fmt else {})) for f,l,fmt in columns]))
        blocks.append(dict(id=id+'_block',type='table',tableId=id,layout='full'))
    def chart(id,title,data,y,ylab,source):
        datasets[id]=rows(data)
        charts.append(dict(id=id,title=title,type='bar',dataset=id,sourceId=source,
                   intent='comparison',question='各方法在相同预测周期和样本上的分数有何不同？',
                   rationale='用分组柱比较离散预测周期与不同方法，保持零起点，避免将不同日期样本误画成时间趋势。',
                   subtitle='同一周期内使用共同样本；纵轴越低越好',showDescription=True,
                   encodings=dict(x=dict(field='周期',type='nominal',label='备货周期'),
                                  y=dict(field=y,type='quantitative',label=ylab),color=dict(field='方法',type='nominal',label='方法')),
                   options=dict(grouping='grouped',orientation='vertical',showLegend=True)))
        blocks.append(dict(id=id+'_block',type='chart',chartId=id,layout='full'))
    md('title','# '+title)
    md('summary','## 本轮结果：简化有帮助，尚未形成可替代MA4的完整方案\n\n'
       'SKU自身周期发生率加一平滑，概率Brier在三个周期都低于未平滑和同画像收缩。'
       '这支持保留概率研究方向，但并未证明概率值已足够可靠。28天的总体差距较小，63/91天仍明显低估需求发生。\n\n'
       '数量端，28天相对MA4的配对MASE差异尚不确定；63/91天的探索性配对区间显示新方案误差更大。'
       'MASE＜1占比略高不能替代真正的模型间比较。业务上最需要关注的“MA4为零、随后是否恢复需求”场景，'
       '新概率AUC约为0.5，目前没有证明它能可靠筛出需要提前准备的SKU。\n\n'
       '建议保留“概率＋条件数量”的信息结构，MA4继续提供数量基准；本轮结果不足以授权自动备货或声称降低库存成本。')
    md('definitions','## 先明确周期、样本和指标\n\n'
       '周数据下30/60/90天对应的是28/63/91天代理，各沿用6个历史起点；原始数据截至2026年8月2日。'
       '242个SKU均进入覆盖审计，但不是每个SKU都在每个起点有完整的训练与未来观察。'
       '本轮沿用此前MA4可评价的2,745个SKU–起点；概率五方法共同样本为2,698个。\n\n'
       '所有方法预测同一未来H周总量，测试目标是原始可观测销量，训练使用起点前的V2需求代理。'
       'MA4仍使用最近4周；新方法沿用最多52周。双方信息截止时点相同，窗口长度各按既定方法定义。\n\n'
       '概率用Brier和可靠性分箱评价；数量用周期MASE。图中的平均Brier/MASE均先在SKU内跨起点平均，再给SKU等权。'
       '表中的中位MASE与MASE＜1占比按SKU–起点计算。每个周期的历史日期范围不同，不将跨周期分数差异解释为纯粹的期限效应。')
    md('prob_result','## 概率比旧同画像方案改善，长期周期仍低估\n\n'
       '加一平滑相对未平滑、同画像收缩的SKU等权Brier差值，三个周期的探索性95%区间均在零以下。'
       '相对企业整体收缩，28天差异不确定，63/91天更差。相对旧周独立换算，三个周期的配对区间都跨零。'
       '下图比较共同样本下的SKU等权Brier；它评价概率，不能拿MA4点预测直接参与。')
    chart('brier_chart','各周期概率Brier比较',p,'brier_sku_macro','SKU等权Brier','prob')
    table('prob_headline','新概率的预测值与实际发生率',p.query("method=='Laplace'"),[
         ('周期','周期',None),('n','SKU–起点数','number'),('observed_event_rate','实际发生率','percent'),
         ('mean_probability','平均预测概率','percent'),('brier_sku_macro','Brier（SKU等权）','number'),('ece_5','五档校准误差','percent'),('auc','AUC','number')],'prob')
    md('calibration','## 平均概率接近，不等于每个概率档都可信\n\n'
       '28/63/91天的平均概率比实际发生率分别低4.4、13.7、19.2个百分点。'
       '28天五档校准误差约5.3个百分点，仍不能根据总体平均接近就宣称已校准。'
       '下表列出每档样本量、平均预测概率与真实发生率，观察其偏差；分箱只是诊断，不是采购阈值。','prob')
    table('calibration_table','加一平滑概率可靠性分箱',rb,[('周期','周期',None),('概率档','概率档',None),('n','样本数','number'),('mean_probability','平均概率','percent'),('observed_event_rate','实际发生率','percent'),('gap','预测减实际','percent')],'bins')
    md('quantity_result','## 数量比较：63/91天平均MASE高于MA4\n\n'
       '本轮期望量使用概率乘条件均值。对同一个SKU–起点，所有模型共用相同训练期周期总量缩放分母。'
       '三个周期主MASE比较分别覆盖741、745、696个SKU–起点。'
       '下图与表格均在相同样本内比较；平均MASE对少数大比例误差敏感，因此同时给出中位数与占比。','cover')
    chart('mase_chart','各周期平均MASE比较',q,'mean_mase_sku_macro','SKU等权Mean MASE','quant')
    table('quantity_table','同样本周期MASE',q,[('周期','周期',None),('方法','方法',None),('n_mase','有效样本','number'),
        ('mean_mase_sku_macro','Mean MASE（SKU等权）','number'),('median_mase','Median MASE','number'),('mase_lt1','MASE＜1占比','percent')],'quant')
    md('pair_result','## 配对区间给出结论边界\n\n'
       '新方案减MA4的SKU等权平均MASE差，28天为+0.123（95%区间−0.044至+0.300），'
       '63天+0.461（+0.280至+0.663），91天+0.306（+0.080至+0.563）。'
       '后两者在本次历史样本中显示误差恶化。改用全部连续历史周期计算分母，方向不变。\n\n'
       '28天区间跨零意味着差异证据不足，不是已经证明非劣。未提供业务可接受误差界值，因此本轮不做非劣效结论。'
       'MASE＜1只代表低于训练期朴素缩放误差；真正逐条优于MA4的占比分别约42.2%、44.2%、42.8%。','paired')
    table('pairs_table','期望量与MA4配对比较',pair,[('周期','周期',None),('n','配对数','number'),('mean_delta_sku_macro','平均MASE差','number'),('ci_low','95%区间下界','number'),('ci_high','95%区间上界','number'),('win_share','逐条优于MA4占比','percent')],'paired')
    md('profile_result','## 低信息SKU的低估仍然存在\n\n'
       '移除同画像参考后，低信息层的概率仍低于实际发生率约12.7、28.0、29.1个百分点。'
       '因此上一轮不能把问题全部归因于同簇借力。它可能还包含历史窗口与需求状态不稳定等影响，本轮没有识别因果。'
       '活跃簇与低频簇的表现也不是完全一致；聚类在这里用于揭示适用范围，不据此事后选择算法。','profile')
    table('profile_probability','新概率的管理画像表现',pprofile,[('周期','周期',None),('画像','画像',None),('n','样本数','number'),('mean_probability','平均概率','percent'),('observed_event_rate','实际发生率','percent'),('brier_sku_macro','Brier（SKU等权）','number')],'profile')
    md('size','## 条件中位数没有带来普遍的误差改善\n\n'
       '只在未来实际发生正需求、且训练有正需求周期的共同样本上，单独比较条件均值和中位数。'
       '本轮条件均值在三个周期的MAE均较低；中位数的抗极端值性质不能直接推出样本外表现更好。'
       '概率乘条件中位数已作为典型量加权参考单独保留，不称为期望量。','conditional')
    table('conditional_table','实际有需求时的数量误差',cond,[('周期','周期',None),('方法','统计量',None),('n','样本数','number'),('mae','MAE','number'),('median_ae','Median AE','number'),('bias','平均数量偏差','number')],'conditional')
    md('business','## 业务增量尚未得到验证\n\n'
       'MA4预测为0不等于未来需求概率为0。在这组样本中，未来发生率仍约30.7%、42.6%、45.8%。'
       '但新概率AUC分别约0.492、0.510、0.491，尚不能有效区分哪些SKU会发生需求。'
       '因此目前只能说概率输出形式符合备货信息需求，不能说这次实现已经提高了备货决策质量。','zero')
    table('zero_table','MA4预测为0时，新概率是否提供排序信息',zero,[('周期','周期',None),('n','样本数','number'),('observed_event_rate','实际发生率','percent'),('mean_probability','平均预测概率','percent'),('auc','AUC','number'),('ece_5','五档校准误差','percent')],'zero')
    md('coverage','## 缺少可计算MASE的记录仍保留\n\n'
       '全242个SKU×18个起点均有覆盖审计。历史不足两个完整周期或训练周期总量不变时，不计算MASE、不加极小数。'
       '没有正需求周期时，概率可以有估计，但条件数量未知。纯算法不编造数量；回退方案仅在这种情况下使用MA4，另表报告。'
       '91天最多只有4个近期历史块，很多新SKU更少，不能隐藏这一数据支撑限制。','cover')
    table('coverage_table','样本覆盖及不可计算原因',coverage,[('周期','周期',None),('base','旧MA4可评价样本','number'),('probability_available','概率可用','number'),('conditional_quantity_available','条件数量可用','number'),('too_few_scale_blocks','不足两个周期','number'),('zero_scale','尺度为0','number'),('main_common_mase','共同MASE样本','number')],'cover')
    md('method','## 方法与验证记录\n\n'
       '对每个历史起点，使用其之前最多52周的连续V2训练片段，按H周从起点向前分块。'
       '若n个完整周期中s个为正，p=(s+1)/(n+2)；条件均值是正需求周期总量的平均。'
       '加一平滑隐含向50%收缩，不能预设其对全部SKU适用。\n\n'
       '独立复核21/21项通过，新增10项unittest通过；检查涵盖原始指纹、旧预测复用、逐条训练分块、'
       '概率与条件均量公式、周期尺度、共同样本、配对区间及覆盖率。没有重复运行清洗以外的旧模型拟合或聚类。'
       '代码正确与模型预测有效是两项不同判断。')
    md('limits','## 研究边界与下一步\n\n'
       '这仍是看过历史结果后的探索性方法开发。1,000次SKU层bootstrap保留同SKU的起点组合，'
       '但未覆盖共同时间冲击，不应当成新增数据确认或多重比较校正后的结论。'
       '销量只是需求代理，缺货、上新和退市缺乏可靠状态字段；MASE也偏好绝对误差意义下的中位数，'
       '不能单独评判期望量或库存决策。\n\n'
       '建议保留分层管理与概率—数量框架，暂不把本轮纯算法替代MA4。28天概率可继续作为研究候选，'
       '63/91天应先处理有效观察期与样本不足问题。下一次检验前需明确真正的业务动作和可接受损失，'
       '再用新增数据验证；不能一边看结果一边修改门槛。\n\n'
       '仍待回答：有效可售期如何识别？发生概率触发什么具体动作？库存和缺货成本能否提供？'
       '没有这些信息，本轮不声称降低库存、提高利润或实现自动采购。')
    artifact=dict(surface='report',manifest=dict(version=1,surface='report',title=title,generatedAt=timestamp,
                  blocks=blocks,charts=charts,tables=tables,sources=sources),
                  snapshot=dict(version=1,status='ready',generatedAt=timestamp,datasets=datasets),sources=sources)
    (REPORT/'artifact.json').write_text(json.dumps(artifact,ensure_ascii=False,indent=2),encoding='utf-8')
    # Concrete packaging blocker: the installed renderer only accepts SQL-source charts,
    # even though this analysis is Python/file-backed. Do not invent SQL provenance.
    def md_table(data, columns):
        labels=[c['label'] for c in columns]
        lines=['| '+' | '.join(labels)+' |','| '+' | '.join(['---']*len(labels))+' |']
        for row in data:
            vals=[]
            for col in columns:
                value=row.get(col['field'])
                if value is None:value='—'
                elif col.get('format')=='percent':value=f'{float(value):.1%}'
                elif isinstance(value,float):value=f'{value:.3f}'
                vals.append(str(value).replace('|','/'))
            lines.append('| '+' | '.join(vals)+' |')
        return '\n'.join(lines)
    texts=[]
    for block in blocks:
        if block['type']=='markdown':texts.append(block['body'].replace('下图','下表').replace('图中的','表中的'))
        elif block['type']=='table':
            t=next(t for t in tables if t['id']==block['tableId'])
            texts.append(md_table(datasets[t['dataset']],t['columns']))
        elif block['type']=='chart' and block['chartId']=='brier_chart':
            texts.append(md_table(datasets['brier_chart'],[dict(field='周期',label='周期'),dict(field='方法',label='方法'),dict(field='brier_sku_macro',label='Brier（SKU等权）')]))
    texts.append('方法文献：[预测误差与MASE](https://otexts.com/fpp3/accuracy.html)；[概率评分规则](https://sites.stat.washington.edu/raftery/Research/PDF/Gneiting2007jasa.pdf)。\n\n完整逐条结果、覆盖审计、公式与独立复核记录见同批结果包。')
    (REPORT/'pxq_v4_3_report.md').write_text('\n\n'.join(texts)+'\n',encoding='utf-8')
    # The lightweight notebook uses standard Python cells; no Jupyter installation needed to inspect it.
    notebook=dict(nbformat=4,nbformat_minor=5,metadata=dict(kernelspec=dict(display_name='Python 3',language='python',name='python3'),
                  language_info=dict(name='python'),execution_note='Code cells executed sequentially with Python exec; Jupyter kernel unavailable and not tested.'),cells=[])
    def cell(kind,text,id):
        x=dict(cell_type=kind,id=id,metadata={},source=text.splitlines(keepends=True))
        if kind=='code':x.update(execution_count=None,outputs=[])
        notebook['cells'].append(x)
    cell('markdown','## tl;dr\n\n简单概率改善了旧同画像方案，但63/91天仍低估；期望量在这两个周期的配对MASE高于MA4。28天差异证据不足。','summary')
    cell('markdown','## Context & Methods\n\n28/63/91天代理，各6个既有起点；完整协议见protocol/amendment_v4.3_simple_probability_mase.md。\n\n### Key Assumptions\n只使用起点前训练数据；期望量=p×条件均值；MASE分母只来自训练期，零尺度缺失；探索性，不能宣称非劣或收益改善。','methods')
    cell('code',"from pathlib import Path\nimport pandas as pd\nimport json\nroot = Path.cwd()\nif not (root/'outputs').exists():\n    root = root.parent.parent\noutput = root/'outputs/pxq_simple_v4_3'\nprint(json.loads((output/'validation_summary.json').read_text())['checks_passed'])",'setup')
    cell('markdown','## Data\n\n输入使用冻结原始数据与V4.2产物；没有重做旧模型。','data')
    cell('code',"c=pd.read_csv(output/'coverage_summary.csv')\nprint(c[['horizon_label','base','probability_available','main_common_mase']].to_string(index=False))",'coverage')
    cell('markdown','## Results\n\n同一周期内比较；不同周期历史日期范围不同。','results')
    cell('code',"p=pd.read_csv(output/'probability_summary.csv')\nprint(p[p.method=='Laplace'][['horizon_label','brier_sku_macro','mean_probability','observed_event_rate']].to_string(index=False))\nq=pd.read_csv(output/'paired_quantity.csv')\nprint(q[(q.method=='Laplace_mean')&(q.baseline=='MA4_proxy')&(q.loss=='mase_52')][['horizon_label','mean_delta_sku_macro','ci_low','ci_high']].to_string(index=False))",'comparison')
    cell('markdown','## Takeaways\n\n21项独立校验通过不等于模型已具备业务价值。MA4为0的子集中，概率AUC约0.5，尚未证明补货筛选增量。\n\n执行说明：当前环境缺少nbclient、nbformat和Jupyter kernel。本笔记的代码单元已通过标准Python按顺序执行并保存输出；未宣称在Jupyter中运行通过。完整重算使用src/pxq_simple_v4_3.py，独立复核使用src/validate_pxq_simple_v4_3.py。','takeaways')
    ns={'__name__':'__main__'}; n=0
    for cellobj in notebook['cells']:
        if cellobj['cell_type']=='code':
            text=''.join(cellobj['source']);ast.parse(text);n+=1
            buf=io.StringIO()
            with contextlib.redirect_stdout(buf):exec(compile(text,'notebook','exec'),ns)
            cellobj['execution_count']=n;cellobj['outputs']=[dict(output_type='stream',name='stdout',text=buf.getvalue().splitlines(keepends=True))]
    (REPORT/'pxq_v4_3_audit.ipynb').write_text(json.dumps(notebook,ensure_ascii=False,indent=2),encoding='utf-8')
    notes=dict(audience='technical',delivery='Markdown + reproducibility bundle; HTML rendering blocked',
               rendering_blocker='Installed portable report validator rejects native charts backed by Python/files unless actual SQL provenance is provided. Two targeted packaging attempts failed; no invented SQL added.',
               required_structure_mapping=['title','summary','definitions before charts','probability / quantities / profiles / management evidence',
                                           'model and validation','limits and robustness','next steps and open questions combined'],
               chart_contracts=[dict(id='brier_chart',family='grouped bar',rows=15,question='概率方法比较',palette='relaxed multi-category, approved shared roots',
                                     non_color='method legend plus fixed group order',footprint='full width',qa='packaged portable verifier'),
                                dict(id='mase_chart',family='grouped bar',rows=9,question='MASE比较',palette='relaxed multi-category, approved shared roots',
                                     non_color='method legend plus fixed group order',footprint='full width',qa='packaged portable verifier')],
               chart_repetition_reason='Both charts answer discrete method-comparison questions with different units; never combine Brier and MASE.',
               table_reason='Reliability requires exact bin probabilities and n; paired intervals and coverage are audit lookups.',
               tests=dict(command='python -m unittest tests.test_pxq_simple_v4_3 -v',passed=10,rerun=False),
               notebook_execution='Sequential standard Python code-cell execution succeeded; Jupyter kernel not available.')
    (REPORT/'source_notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2),encoding='utf-8')
    # Inspectable SKU-level scores without refitting any models.
    qc=read('quantity_common').dropna(subset=['mase_52'])
    skus=qc.groupby(['horizon_label','sku','method']).agg(valid_origins=('origin_index','nunique'),mean_mase=('mase_52','mean'),mae=('ae','mean')).reset_index()
    skus.to_csv(REPORT/'sku_model_scores.csv',index=False)
    print(json.dumps(dict(artifact=str(REPORT/'artifact.json'),notebook=str(REPORT/'pxq_v4_3_audit.ipynb'),blocks=len(blocks),charts=len(charts)),ensure_ascii=False))


if __name__=='__main__':build()
