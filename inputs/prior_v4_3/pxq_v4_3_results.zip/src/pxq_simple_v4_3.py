"""V4.3 additive retrospective evaluation; never refits or overwrites old models."""
from __future__ import annotations

import hashlib
import json
import platform
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from sklearn.metrics import roc_auc_score

from .backtesting import _ending_contiguous_training_segment
from .cleaning_v2 import apply_v2_cleaning
from .config import load_config
from .data_audit import load_workbook_long, sha256_file
from .pxq_two_part_v4_2 import (
    _exclusive_output_lock, _write_csv, _write_json,
    backward_nonoverlapping_block_totals,
)

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "outputs/pxq_simple_v4_3"
KEY = ["horizon_label", "origin_index", "sku"]
META = KEY + ["horizon_weeks", "approximate_days", "origin", "cluster_profile", "actual_sum", "actual_event"]
PROB_METHODS = ["Laplace", "SKU_recent_block", "PXQ_independence", "EnterpriseShrink_L4", "ProfileShrink_L4"]
PURE_METHODS = ["Laplace_mean", "Laplace_median_proxy", "MA4_proxy", "Naive", "PXQ", "ProfileShrink_L4_expected", "SKU_recent_block_expected"]
PRIMARY = "Laplace_mean"


def laplace_probability(s: int, n: int) -> float:
    if n < 0 or s < 0 or s > n:
        raise ValueError("Invalid event counts")
    return float((s + 1) / (n + 2)) if n > 0 else np.nan


def block_scale(totals: np.ndarray) -> float:
    a = np.asarray(totals, dtype=float)
    if np.any(~np.isfinite(a)) or np.any(a < 0):
        raise ValueError("Invalid training totals")
    return float(np.abs(np.diff(a)).mean()) if len(a) >= 2 else np.nan


def estimate(totals: np.ndarray) -> dict:
    a = np.asarray(totals, dtype=float)
    n, s = len(a), int((a > 0).sum())
    p = laplace_probability(s, n)
    pos = a[a > 0]
    mean, median = (float(pos.mean()), float(np.median(pos))) if s else (np.nan, np.nan)
    scale = block_scale(a)
    return dict(n=n, s=s, p=p, q_mean=mean, q_median=median,
                Laplace_mean=p * mean, Laplace_median_proxy=p * median,
                scale_52=scale, scale_status=("too_few_blocks" if n < 2 else "zero_scale" if scale == 0 else "valid"))


def common_sample(frame: pd.DataFrame, methods: list[str], value: str) -> pd.DataFrame:
    sub = frame.loc[frame.method.isin(methods) & np.isfinite(frame[value])].copy()
    if sub.duplicated(KEY + ["method"]).any():
        raise ValueError("Duplicate prediction key")
    counts = sub.groupby(KEY).method.nunique()
    valid = counts[counts == len(methods)].reset_index()[KEY]
    return sub.merge(valid, on=KEY, validate="many_to_one")


def paired(frame: pd.DataFrame, primary: str, baseline: str, loss: str) -> dict:
    # Pair at SKU-origin BEFORE taking SKU means (avoid mismatched origins).
    sub = common_sample(frame, [primary, baseline], loss)
    wide = sub.pivot(index=KEY, columns="method", values=loss)
    if wide.empty:
        return dict(method=primary, baseline=baseline, loss=loss, n=0)
    d = wide[primary] - wide[baseline]
    sku_d = d.groupby(level="sku").mean().to_numpy()
    rng = np.random.default_rng(42)
    boot = np.mean(rng.choice(sku_d, (1000, len(sku_d)), replace=True), axis=1)
    origins = d.groupby(level="origin_index").mean()
    return dict(method=primary, baseline=baseline, loss=loss, n=len(d), n_skus=len(sku_d),
                mean_delta_sku_macro=float(sku_d.mean()), ci_low=float(np.quantile(boot, .025)),
                ci_high=float(np.quantile(boot, .975)), win_share=float((d < -1e-12).mean()),
                tie_share=float((abs(d) <= 1e-12).mean()), winning_origins=int((origins < 0).sum()),
                total_origins=len(origins), noninferiority="not_tested_no_business_margin")


def probability_summary(frame: pd.DataFrame, group: list[str]) -> pd.DataFrame:
    rows = []
    for keys, g in frame.groupby(group, sort=True):
        if not isinstance(keys, tuple):
            keys = (keys,)
        p, z = g.probability.to_numpy(), g.actual_event.to_numpy()
        loss = (p - z) ** 2
        bysku = pd.Series(loss, index=g.sku).groupby(level=0).mean()
        idx = np.minimum((p * 5).astype(int), 4)
        ece = sum(abs(np.mean(p[idx == b] - z[idx == b])) * np.mean(idx == b) for b in np.unique(idx))
        rows.append(dict(zip(group, keys)) | dict(n=len(g), n_skus=g.sku.nunique(),
                    observed_event_rate=float(z.mean()), mean_probability=float(p.mean()),
                    calibration_gap=float(p.mean()-z.mean()), brier=float(loss.mean()),
                    brier_sku_macro=float(bysku.mean()), ece_5=float(ece),
                    auc=float(roc_auc_score(z, p)) if len(np.unique(z)) == 2 else np.nan))
    return pd.DataFrame(rows)


def quantity_summary(frame: pd.DataFrame, group: list[str], scale_col: str = "mase_52") -> pd.DataFrame:
    rows = []
    for keys, g in frame.groupby(group, sort=True):
        if not isinstance(keys, tuple):
            keys = (keys,)
        valid = g[np.isfinite(g[scale_col])]
        total = g.actual_sum.sum()
        sm = valid.groupby("sku")[scale_col].mean()
        rows.append(dict(zip(group, keys)) | dict(n=len(g), n_skus=g.sku.nunique(),
             n_mase=len(valid), n_skus_mase=valid.sku.nunique(), mean_mase=float(valid[scale_col].mean()),
             mean_mase_sku_macro=float(sm.mean()), median_mase=float(valid[scale_col].median()),
             median_sku_mean_mase=float(sm.median()), mase_lt1=float((valid[scale_col] < 1).mean()) if len(valid) else np.nan,
             mae=float(g.ae.mean()), median_ae=float(g.ae.median()), wape=float(g.ae.sum()/total) if total else np.nan,
             bias_units=float(g.error.mean()), bias_ratio=float(g.error.sum()/total) if total else np.nan,
             underforecast_units=float(np.maximum(-g.error, 0).sum()), overforecast_units=float(np.maximum(g.error,0).sum())))
    return pd.DataFrame(rows)


def reliability(frame: pd.DataFrame) -> pd.DataFrame:
    f = frame.copy()
    f["bin"] = np.minimum((f.probability * 5).astype(int), 4)
    r = f.groupby(["horizon_label", "method", "bin"]).agg(n=("sku", "size"), n_skus=("sku", "nunique"),
            mean_probability=("probability", "mean"), observed_event_rate=("actual_event", "mean")).reset_index()
    r["lower"] = r["bin"] / 5
    r["upper"] = (r["bin"] + 1) / 5
    r["gap"] = r.mean_probability - r.observed_event_rate
    return r


def verify_existing_manifest() -> dict:
    # Verify only the inputs we consume, not mutable presentation reports.
    wanted = ["two_part_components.csv", "probability_predictions.csv", "expected_quantity_predictions.csv"]
    manifest = pd.read_csv(ROOT / "outputs/pxq_two_part_v4_2/manifest_sha256.csv")
    result = {}
    for name in wanted:
        rel = f"outputs/pxq_two_part_v4_2/{name}"
        exp = manifest.loc[manifest.relative_path.eq(rel), "sha256"].item()
        actual = sha256_file(ROOT / rel)
        if actual != exp:
            raise RuntimeError(f"Historical input fingerprint mismatch: {name}")
        result[rel] = actual
    for rel in ["config/pxq_two_part_v4_2.yaml", "protocol/amendment_v4.3_simple_probability_mase.md", "src/pxq_simple_v4_3.py", "outputs/pxq_validation_v4/rolling_origin_predictions.csv"]:
        result[rel] = sha256_file(ROOT / rel)
    return result


def prepare(cfg: dict, old: pd.DataFrame, prior: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict]:
    loaded = load_workbook_long(ROOT/cfg["input"]["workbook"], metadata_columns=8, sku_column="SKU", minimum_covered_days=7)
    assert loaded.audit["sha256"] == cfg["input"]["expected_sha256"] and not loaded.audit["blockers"]
    raw = loaded.weekly_complete
    allsku = sorted(loaded.weekly_all.sku.astype(str).unique())
    assert not old.duplicated(KEY).any()
    raw_by_sku = {str(s):g.set_index("week_start")["sales"] for s,g in raw.groupby("sku")}
    additions, blocks, coverage = [], [], []
    groups = list(old.groupby(["horizon_label", "origin_index"], sort=True))
    for ix, ((hlabel, oi), g) in enumerate(groups, 1):
        origin = pd.Timestamp(g.origin.iloc[0]); h = int(g.horizon_weeks.iloc[0])
        clean = apply_v2_cleaning(raw.loc[raw.week_start < origin], **cfg["cleaning_v2"])
        training = {str(s):f for s,f in clean.weekly.groupby("sku", sort=False)}
        gmap = g.set_index("sku")
        target_dates = pd.date_range(origin, periods=h, freq="7D")
        for sku in allsku:
            train = training.get(sku)
            seg = _ending_contiguous_training_segment(train, origin, "sales_v2") if train is not None else pd.DataFrame(columns=["sales_v2"])
            a = seg.sales_v2.to_numpy(dtype=float)
            expected = raw_by_sku.get(sku, pd.Series(dtype=float)).reindex(target_dates)
            test_ok = expected.notna().all()
            inbase = sku in gmap.index
            reason = "eligible" if inbase else "training_missing_or_less_than_4_weeks" if len(a) < 4 else "incomplete_future_observation" if not test_ok else "other_inherited_exclusion"
            coverage.append(dict(horizon_label=hlabel, horizon_weeks=h, origin_index=oi, origin=str(origin.date()), sku=sku,
                                 in_old_base=inbase, training_weeks=len(a), complete_future_weeks=int(expected.notna().sum()), reason=reason))
            if not inbase:
                continue
            assert len(a) >= 4 and test_ok
            row = gmap.loc[sku]
            assert np.isclose(float(expected.sum()), row.actual_sum)
            totals = backward_nonoverlapping_block_totals(a, h, 52)
            full = backward_nonoverlapping_block_totals(a, h, len(a))
            e = estimate(totals)
            assert e["n"] == row.complete_history_blocks and e["s"] == row.positive_history_blocks
            assert np.isclose(totals.sum(), row.positive_history_volume)
            ma4 = prior.loc[prior.horizon_label.eq(hlabel) & prior.origin_index.eq(oi) & prior.sku.eq(sku) & prior.model.eq("MA4_proxy"), "forecast_sum"].item()
            assert np.isclose(ma4, h * a[-4:].mean())
            additions.append(dict(horizon_label=hlabel, origin_index=oi, sku=sku, **e, scale_full=block_scale(full),
                                  full_n=len(full), last_block_total=float(totals[-1]) if len(totals) else np.nan,
                                  training_tail4_mean=float(a[-4:].mean()), ma4_forecast=ma4,
                                  Laplace_mean_else_MA4=e["Laplace_mean"] if np.isfinite(e["Laplace_mean"]) else ma4,
                                  quantity_source="own_positive_blocks" if e["s"] else "MA4_fallback",
                                  training_last_week=str((origin-pd.Timedelta(weeks=1)).date())))
            for j, val in enumerate(full):
                end = origin - pd.Timedelta(weeks=(len(full)-j-1)*h+1)
                start = end - pd.Timedelta(weeks=h-1)
                blocks.append(dict(horizon_label=hlabel, origin_index=oi, sku=sku, block_index=j,
                                  block_start=str(start.date()), block_end=str(end.date()), total=float(val),
                                  in_recent52=j >= len(full)-len(totals)))
        print(f"Training audit {ix}/{len(groups)}: {hlabel}, {origin.date()}, {len(g)} SKU-origins; old totals/MA4 agree.", flush=True)
    comp = old.merge(pd.DataFrame(additions), on=KEY, validate="one_to_one")
    return comp, pd.DataFrame(blocks), pd.DataFrame(coverage), loaded.audit


def evaluate(comp: pd.DataFrame, oldq: pd.DataFrame, oldp: pd.DataFrame) -> dict[str, pd.DataFrame]:
    newp = comp[META].copy(); newp["method"]="Laplace"; newp["probability"]=comp.p
    probs = pd.concat([oldp.loc[oldp.method.isin(PROB_METHODS), META+["method","probability"]], newp], ignore_index=True)
    probs = probs.loc[np.isfinite(probs.probability)].copy()
    probs["brier_loss"] = (probs.probability-probs.actual_event)**2
    pc = common_sample(probs, PROB_METHODS, "probability")
    qframes = [oldq.loc[:, META+["method","forecast_sum"]]]
    for method in ["Laplace_mean", "Laplace_median_proxy", "Laplace_mean_else_MA4"]:
        f = comp[META].copy(); f["method"]=method; f["forecast_sum"]=comp[method]; qframes.append(f)
    quantities = pd.concat(qframes, ignore_index=True).dropna(subset=["forecast_sum"])
    quantities = quantities.merge(comp[KEY+["scale_52", "scale_full", "n", "s", "p", "quantity_source"]], on=KEY, validate="many_to_one")
    quantities["error"] = quantities.forecast_sum - quantities.actual_sum
    quantities["ae"] = abs(quantities.error)
    for scale, col in [("scale_52", "mase_52"), ("scale_full", "mase_full")]:
        quantities[col] = quantities.ae / quantities[scale].where(quantities[scale] > 0)
    qc = common_sample(quantities, PURE_METHODS, "forecast_sum")
    op = common_sample(quantities, ["Laplace_mean_else_MA4", "MA4_proxy", "Naive"], "forecast_sum")
    tables = {"components": comp, "probability_predictions": probs, "quantity_predictions": quantities,
        "probability_common": pc, "quantity_common": qc,
        "probability_summary": probability_summary(pc,["horizon_label","method"]),
        "probability_native_summary": probability_summary(probs,["horizon_label","method"]),
        "probability_by_profile": probability_summary(pc,["horizon_label","cluster_profile","method"]),
        "probability_by_origin": probability_summary(pc,["horizon_label","origin_index","method"]),
        "quantity_summary": quantity_summary(qc,["horizon_label","method"]),
        "quantity_native_summary": quantity_summary(quantities,["horizon_label","method"]),
        "quantity_operational_summary": quantity_summary(op,["horizon_label","method"]),
        "quantity_by_profile": quantity_summary(qc,["horizon_label","cluster_profile","method"]),
        "quantity_by_origin": quantity_summary(qc,["horizon_label","origin_index","method"]),
        "quantity_full_scale_sensitivity": quantity_summary(qc,["horizon_label","method"], "mase_full"),
        "reliability_bins": reliability(pc)}
    pairs=[]
    for label, pp in probs.groupby("horizon_label"):
        for baseline in PROB_METHODS[1:]:
            pairs.append(dict(horizon_label=label, **paired(pp,"Laplace",baseline,"brier_loss")))
    tables["paired_probability"]=pd.DataFrame(pairs)
    pairs=[]
    for label, qq in quantities.groupby("horizon_label"):
        for method in ["Laplace_mean", "Laplace_median_proxy", "Laplace_mean_else_MA4", "PXQ", "ProfileShrink_L4_expected"]:
            for baseline in ["MA4_proxy", "Naive"]:
                for loss in ["mase_52", "mase_full", "ae"]:
                    pairs.append(dict(horizon_label=label, **paired(qq, method, baseline, loss)))
    tables["paired_quantity"]=pd.DataFrame(pairs)
    # Conditional size evaluation: only positive outcomes and identical available q samples.
    rows=[]
    for label,g in comp.loc[comp.s.gt(0) & comp.actual_event.eq(1)].groupby("horizon_label"):
        for method in ["q_mean", "q_median"]:
            e=g[method]-g.actual_sum
            rows.append(dict(horizon_label=label, method=method, n=len(g), n_skus=g.sku.nunique(),
                             mae=float(abs(e).mean()), median_ae=float(abs(e).median()), bias=float(e.mean())))
    tables["conditional_quantity_summary"]=pd.DataFrame(rows)
    # Management diagnostic does not create a procurement rule or probability cutoff.
    mz = newp.loc[comp.ma4_forecast.eq(0) & np.isfinite(comp.p)].copy()
    tables["ma4_zero_probability"]=probability_summary(mz,["horizon_label","method"])
    tables["ma4_zero_reliability"]=reliability(mz)
    support=comp.groupby(["horizon_label","n","s","scale_status"]).agg(n_sku_origins=("sku","size"), n_skus=("sku","nunique"),
                 actual_event_rate=("actual_event","mean"), actual_volume=("actual_sum","sum"),mean_probability=("p","mean")).reset_index()
    tables["history_support"]=support
    cov=[]
    validkeys=qc.loc[np.isfinite(qc.mase_52), KEY].drop_duplicates()
    for label,g in comp.groupby("horizon_label"):
        k=validkeys[validkeys.horizon_label.eq(label)]
        cov.append(dict(horizon_label=label, base=len(g), n_skus=g.sku.nunique(), probability_available=int(g.n.gt(0).sum()),
                        conditional_quantity_available=int(g.s.gt(0).sum()), no_positive_history=int(g.s.eq(0).sum()),
                        too_few_scale_blocks=int(g.n.lt(2).sum()), zero_scale=int(g.scale_52.eq(0).sum()),
                        valid_scale=int(g.scale_52.gt(0).sum()), main_common_mase=len(k), main_common_mase_skus=k.sku.nunique(),
                        unavailable_q_actual_event_rate=float(g.loc[g.s.eq(0),"actual_event"].mean()),
                        unavailable_q_actual_volume=float(g.loc[g.s.eq(0),"actual_sum"].sum())))
    tables["coverage_summary"]=pd.DataFrame(cov)
    return tables


def run() -> None:
    if (OUT/"outcome.json").exists():
        raise RuntimeError("Completed V4.3 outputs exist; inspect instead of rerunning")
    cfg=load_config(ROOT/"config/pxq_two_part_v4_2.yaml")
    hashes=verify_existing_manifest()
    with _exclusive_output_lock(OUT):
        _write_json(OUT/"frozen_inputs.json",dict(created_at=pd.Timestamp.now(tz="UTC").isoformat(), inputs=hashes,
               protocol="4.3", lookback=52, laplace_alpha=1, seed=42, bootstrap_repetitions=1000,
               primary_probability="Laplace", primary_quantity=PRIMARY, noninferiority_margin=None,
               environment=dict(python=platform.python_version(),pandas=pd.__version__,numpy=np.__version__,scipy=scipy.__version__)))
        old=pd.read_csv(ROOT/"outputs/pxq_two_part_v4_2/two_part_components.csv", dtype={"sku":str})
        prior=pd.read_csv(ROOT/cfg["input"]["v4_predictions"], dtype={"sku":str})
        comp, blocks, cov, audit=prepare(cfg,old,prior)
        _write_csv(OUT/"training_blocks.csv", blocks)
        _write_csv(OUT/"universe_coverage.csv", cov)
        _write_json(OUT/"input_audit.json",audit)
        op=pd.read_csv(ROOT/"outputs/pxq_two_part_v4_2/probability_predictions.csv",dtype={"sku":str})
        oq=pd.read_csv(ROOT/"outputs/pxq_two_part_v4_2/expected_quantity_predictions.csv",dtype={"sku":str})
        tables=evaluate(comp,oq,op)
        for name, f in tables.items():
            _write_csv(OUT/f"{name}.csv",f)
            assert len(pd.read_csv(OUT/f"{name}.csv"))==len(f)
        _write_json(OUT/"outcome.json",dict(protocol="4.3",confirmatory=False,reused_previous_predictions=True,
                    unique_source_skus=audit["unique_skus"],data_end=audit["week_start_max"],
                    source_sku_origin_slots=len(cov),component_rows=len(comp),
                    probability_common_rows=len(tables["probability_common"]),quantity_common_rows=len(tables["quantity_common"]),
                    noninferiority_tested=False,business_cost_savings_tested=False))
        for rel,h in hashes.items():
            assert sha256_file(ROOT/rel)==h, f"Input changed during run: {rel}"
        files=sorted(p for p in OUT.iterdir() if p.is_file() and not p.name.startswith("."))
        _write_csv(OUT/"manifest_sha256.csv",pd.DataFrame([dict(file=p.name,sha256=sha256_file(p)) for p in files]))
        print("V4.3 complete. Old predictions unchanged; independent validation is still required.",flush=True)


if __name__ == "__main__":
    run()
