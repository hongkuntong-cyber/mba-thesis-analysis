"""Independent arithmetic, sample and provenance checks; no model refitting."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'outputs/pxq_simple_v4_3'
KEY=['horizon_label','origin_index','sku']


def verify():
    checks=[]
    def check(name, ok, details=None):
        checks.append(dict(check=name,passed=bool(ok),details=details))
        if not ok:
            raise AssertionError(name)
    def read(name):
        return pd.read_csv(OUT/(name+'.csv'),dtype={'sku':str})
    manifest=read('manifest_sha256')
    check('output_hashes',all(hashlib.sha256((OUT/r.file).read_bytes()).hexdigest()==r.sha256 for r in manifest.itertuples()))
    frozen=json.loads((OUT/'frozen_inputs.json').read_text())
    check('inputs_unchanged',all(hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h for f,h in frozen['inputs'].items()))
    c=read('components'); b=read('training_blocks'); p=read('probability_predictions'); q=read('quantity_predictions')
    check('unique_prediction_grain',not c.duplicated(KEY).any() and not p.duplicated(KEY+['method']).any() and not q.duplicated(KEY+['method']).any())
    old=pd.read_csv(ROOT/'outputs/pxq_two_part_v4_2/two_part_components.csv',dtype={'sku':str})
    check('base_exactly_preserved',set(map(tuple,c[KEY].to_numpy()))==set(map(tuple,old[KEY].to_numpy())))
    check('laplace_formula',np.allclose(c.loc[c.n.gt(0),'p'],(c.loc[c.n.gt(0),'s']+1)/(c.loc[c.n.gt(0),'n']+2)))
    check('missing_not_invented',c.loc[c.n.eq(0),'p'].isna().all() and c.loc[c.s.eq(0),['q_mean','q_median','Laplace_mean','Laplace_median_proxy']].isna().all().all())
    cmap=c.set_index(KEY); rg={key:g for key,g in b.groupby(KEY)}
    rows_ok=True
    for key,row in cmap.iterrows():
        g=rg.get(key,pd.DataFrame(columns=['total','in_recent52']))
        a=g.loc[g.in_recent52.eq(True),'total'].to_numpy(dtype=float)
        x=a[a>0]
        rows_ok &= len(a)==row.n and len(x)==row.s and np.isclose(sum(a),row.positive_history_volume)
        if len(x):
            rows_ok &= np.isclose(sum(x)/len(x),row.q_mean) and np.isclose(np.median(x),row.q_median)
        if len(a)>=2:
            scale=sum(abs(float(a[i])-float(a[i-1])) for i in range(1,len(a)))/(len(a)-1)
            rows_ok &= np.isclose(scale,row.scale_52)
        if len(g):
            rows_ok &= bool((pd.to_datetime(g.block_end)<pd.Timestamp(row.origin)).all())
    check('all_training_blocks_means_medians_scales_dates',rows_ok)
    check('quantity_expectation_and_proxy',np.allclose(c.Laplace_mean,c.p*c.q_mean,equal_nan=True) and np.allclose(c.Laplace_median_proxy,c.p*c.q_median,equal_nan=True))
    check('ma4_exact_cycle_definition',np.allclose(c.ma4_forecast,c.horizon_weeks*c.training_tail4_mean))
    check('fallback_only_when_missing_q',np.allclose(c.Laplace_mean_else_MA4,np.where(c.Laplace_mean.notna(),c.Laplace_mean,c.ma4_forecast)))
    check('probability_bounds_and_brier',p.probability.between(0,1).all() and np.allclose(p.brier_loss,(p.probability-p.actual_event)**2))
    check('all_period_losses',np.allclose(q.ae,abs(q.forecast_sum-q.actual_sum)) and np.allclose(q.mase_52,q.ae/q.scale_52.where(q.scale_52.gt(0)),equal_nan=True))
    check('zero_scale_never_epsilon',q.loc[q.scale_52.eq(0),'mase_52'].isna().all())
    oldq=pd.read_csv(ROOT/'outputs/pxq_two_part_v4_2/expected_quantity_predictions.csv',dtype={'sku':str})
    a=oldq[KEY+['method','forecast_sum']].sort_values(KEY+['method']).reset_index(drop=True)
    x=q.loc[q.method.isin(oldq.method.unique()),KEY+['method','forecast_sum']].sort_values(KEY+['method']).reset_index(drop=True)
    check('old_forecasts_exactly_reused',a[KEY+['method']].equals(x[KEY+['method']]) and np.allclose(a.forecast_sum,x.forecast_sum))
    qc=read('quantity_common'); pc=read('probability_common')
    check('common_samples_complete',qc.groupby(KEY).method.nunique().eq(7).all() and pc.groupby(KEY).method.nunique().eq(5).all())
    qs=read('quantity_summary'); ps=read('probability_summary')
    summary_ok=True
    for r in qs.itertuples():
        g=qc.loc[qc.horizon_label.eq(r.horizon_label)&qc.method.eq(r.method)]
        valid=g.dropna(subset=['mase_52'])
        macro=valid.groupby('sku').mase_52.mean().mean()
        summary_ok &= len(g)==r.n and len(valid)==r.n_mase and np.isclose(macro,r.mean_mase_sku_macro) and np.isclose(valid.mase_52.median(),r.median_mase)
    for r in ps.itertuples():
        g=pc.loc[pc.horizon_label.eq(r.horizon_label)&pc.method.eq(r.method)]
        loss=(g.probability-g.actual_event)**2
        macro=loss.groupby(g.sku).mean().mean()
        summary_ok &= len(g)==r.n and np.isclose(loss.mean(),r.brier) and np.isclose(macro,r.brier_sku_macro)
    check('independent_headline_aggregations',summary_ok)
    pairs=read('paired_quantity'); pairs_ok=True
    for r in pairs.loc[pairs.method.eq('Laplace_mean')&pairs.baseline.eq('MA4_proxy')&pairs.loss.eq('mase_52')].itertuples():
        g=q.loc[q.horizon_label.eq(r.horizon_label)&q.method.isin([r.method,r.baseline])]
        w=g.pivot(index=KEY,columns='method',values='mase_52').dropna()
        d=(w[r.method]-w[r.baseline]).groupby(level='sku').mean().to_numpy()
        rng=np.random.default_rng(42)
        means=np.array([rng.choice(d,len(d),replace=True).mean() for _ in range(1000)])
        pairs_ok &= len(w)==r.n and np.isclose(d.mean(),r.mean_delta_sku_macro) and np.isclose(np.quantile(means,.025),r.ci_low) and np.isclose(np.quantile(means,.975),r.ci_high)
    check('paired_mase_differences_and_bootstrap',pairs_ok)
    rb=read('reliability_bins')
    check('reliability_counts',int(rb.n.sum())==len(pc))
    cov=read('universe_coverage')
    check('all_242_skus_all_18_slots_audited',len(cov)==242*18 and cov.sku.nunique()==242 and cov.groupby('horizon_label').origin_index.nunique().eq(6).all())
    check('coverage_reconciles',int(cov.in_old_base.sum())==len(c) and len(c)==2745)
    profiles=read('quantity_by_profile')
    check('profile_counts_sum_to_overall',np.array_equal(profiles.groupby(['horizon_label','method']).n.sum().to_numpy(),qs.set_index(['horizon_label','method']).sort_index().n.to_numpy()))
    outcome=dict(valid=True,checks_passed=len(checks),checks_total=len(checks),checks=checks,
                 confirmatory=False,noninferiority_proved=False,business_savings_proved=False)
    target=OUT/'validation_summary.json'; temp=target.with_suffix('.tmp')
    temp.write_text(json.dumps(outcome,ensure_ascii=False,indent=2));temp.replace(target)
    print(json.dumps(dict(valid=True,checks_passed=len(checks)),ensure_ascii=False))
    return outcome


if __name__=='__main__':
    verify()
