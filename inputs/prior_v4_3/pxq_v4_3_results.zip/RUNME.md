# V4.3 复算说明

本结果包对应2026年9月6日冻结的探索性协议。新增计算已完成，10项新增unittest通过，
21项独立复核通过；没有重跑此前聚类或五个数量模型。

## 先看结果

- reports/pxq_simple_v4_3/pxq_v4_3_report.md：完整结论与数字。
- outputs/pxq_simple_v4_3/probability_summary.csv：共同样本概率比较。
- outputs/pxq_simple_v4_3/quantity_summary.csv：同样本周期MASE与数量误差。
- outputs/pxq_simple_v4_3/paired_quantity.csv：真正的模型配对比较与探索性区间。
- outputs/pxq_simple_v4_3/coverage_summary.csv、universe_coverage.csv：保留全242个SKU的覆盖记录。
- reports/pxq_simple_v4_3/sku_model_scores.csv：逐SKU、逐周期模型分数。
- outputs/pxq_simple_v4_3/components.csv：概率、条件均值、条件中位数、历史n/s及缺失原因。

MASE<1不是击败测试期Naive；p乘条件中位数不是期望量；区间跨0不是非劣效证明。
不同周期的历史日期范围不同。没有库存、在途与损失成本，本轮未证明业务收益。

## 独立复核（不重跑模型）

在解压根目录，使用安装了项目requirements.txt所列科学计算依赖的Python：

    python -m src.validate_pxq_simple_v4_3

## 重现新增计算

先把 outputs/pxq_simple_v4_3 改名保存，例如改为 pxq_simple_v4_3_saved，
保留所有旧版本输入目录，再运行：

    python -m src.pxq_simple_v4_3
    python -m src.validate_pxq_simple_v4_3

脚本检测到已有完成结果时会拒绝覆盖。原始Excel及旧预测已作为必要输入包含，
无需从云端重新下载或重新拟合旧模型。原始指纹与协议/代码指纹可在frozen_inputs.json核对。
实际运行环境版本见同文件environment字段。单元测试可用：

    python -m unittest tests.test_pxq_simple_v4_3 -v

## 笔记与报告显示限制

pxq_v4_3_audit.ipynb的标准Python代码单元已顺序执行并保存输出；当前环境未安装
Jupyter kernel/nbclient/nbformat，因此不声称在Jupyter内执行验证完成。Python脚本计算与独立复核已完成。
网页报告工具拒绝非SQL来源的图表，未伪造SQL；故交付Markdown及CSV作为可读、可复核结果。

packet_manifest.json记录包内逐文件SHA256。数据属于已查看过的历史样本，不是新增数据确认。
