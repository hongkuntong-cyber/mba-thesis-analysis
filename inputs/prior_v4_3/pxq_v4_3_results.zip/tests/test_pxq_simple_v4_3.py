import unittest
import numpy as np
import pandas as pd
from src.pxq_simple_v4_3 import laplace_probability, block_scale, estimate, common_sample, paired


class SimpleProbabilityTests(unittest.TestCase):
    def test_laplace_counts(self):
        self.assertAlmostEqual(laplace_probability(1,4),1/3)
        self.assertAlmostEqual(laplace_probability(0,4),1/6)
        self.assertAlmostEqual(laplace_probability(4,4),5/6)

    def test_invalid_counts(self):
        with self.assertRaises(ValueError): laplace_probability(5,4)

    def test_zero_history_not_50_percent(self):
        self.assertTrue(np.isnan(laplace_probability(0,0)))

    def test_no_positive_q_not_fabricated(self):
        r=estimate(np.array([0,0,0]))
        self.assertTrue(np.isfinite(r['p']))
        self.assertTrue(np.isnan(r['q_mean']))
        self.assertTrue(np.isnan(r['Laplace_mean']))
        self.assertEqual(r['scale_status'],'zero_scale')

    def test_mean_median_different_estimands(self):
        r=estimate(np.array([0,1,1,10]))
        self.assertEqual(r['q_mean'],4)
        self.assertEqual(r['q_median'],1)
        self.assertAlmostEqual(r['Laplace_mean'],8/3)

    def test_scale_uses_period_totals(self):
        self.assertAlmostEqual(block_scale(np.array([2,5,1])),3.5)

    def test_scale_one_block_missing(self):
        self.assertTrue(np.isnan(block_scale(np.array([8]))))

    def test_constant_positive_scale_zero(self):
        self.assertEqual(estimate(np.array([3,3,3]))['scale_status'],'zero_scale')

    def test_pair_before_sku_mean(self):
        df=pd.DataFrame([dict(horizon_label='h',origin_index=1,sku='s',method='a',loss=2.),
                         dict(horizon_label='h',origin_index=2,sku='s',method='a',loss=100.),
                         dict(horizon_label='h',origin_index=1,sku='s',method='b',loss=1.)])
        r=paired(df,'a','b','loss')
        self.assertEqual(r['n'],1)
        self.assertEqual(r['mean_delta_sku_macro'],1)

    def test_common_rejects_duplicates(self):
        df=pd.DataFrame([dict(horizon_label='h',origin_index=1,sku='s',method='a',loss=2.)]*2)
        with self.assertRaises(ValueError): common_sample(df,['a'],'loss')


if __name__ == '__main__':
    unittest.main()
